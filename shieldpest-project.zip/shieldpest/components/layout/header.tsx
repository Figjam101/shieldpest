'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Phone, Shield, Menu, X } from 'lucide-react';
import { siteConfig } from '@/data/site-config';

const navLinks = [
  { label: 'Services', href: '/services' },
  { label: 'Locations', href: '/locations' },
  { label: 'About', href: '/about' },
  { label: 'Blog', href: '/blog' },
  { label: 'FAQ', href: '/faq' },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-navy-900/97 backdrop-blur-md border-b border-white/[0.08] py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container-site flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 no-underline">
          <Shield className="w-7 h-7 text-ember-500" />
          <span className="font-display font-extrabold text-xl text-white tracking-tight">
            Shield<span className="text-ember-400">Pest</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="font-body text-sm font-medium text-white/80 no-underline hover:text-white transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* CTA Group */}
        <div className="flex items-center gap-4">
          <a
            href={`tel:${siteConfig.phoneTel}`}
            className="flex items-center gap-2 font-body text-sm font-semibold text-white no-underline"
          >
            <Phone className="w-4 h-4 text-ember-400" />
            <span className="hidden md:inline">{siteConfig.phone}</span>
          </a>
          <Link
            href="/quote"
            className="font-body text-[0.85rem] font-semibold tracking-wide text-white bg-ember-500 px-5 py-2.5 rounded-lg no-underline hover:bg-ember-600 transition-colors"
          >
            Free Quote
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden text-white p-1"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div className="lg:hidden bg-navy-900/98 backdrop-blur-lg border-t border-white/[0.08]">
          <nav className="container-site py-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="font-body text-base font-medium text-white/80 no-underline hover:text-white py-2"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/contact"
              onClick={() => setMobileOpen(false)}
              className="font-body text-base font-semibold text-ember-400 no-underline py-2"
            >
              Contact Us
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
