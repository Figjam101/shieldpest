'use client';

import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FadeUp } from '@/components/ui/fade-up';
import { faqs } from '@/data/faqs';

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="bg-surface-50 section-padding">
      <div className="max-w-[800px] mx-auto px-6">
        <FadeUp>
          <div className="text-center mb-14">
            <span className="label-overline block mb-3">FAQ</span>
            <h2 className="font-display font-extrabold text-h2 text-navy-900">
              Common Questions
            </h2>
          </div>
        </FadeUp>

        <div className="flex flex-col gap-3">
          {faqs.map((faq, i) => (
            <FadeUp key={i} delay={i * 0.05}>
              <div
                className={`bg-white rounded-[14px] border transition-colors ${
                  openIndex === i ? 'border-ember-400' : 'border-surface-200'
                } overflow-hidden`}
              >
                <button
                  onClick={() => setOpenIndex(openIndex === i ? null : i)}
                  className="w-full px-6 py-5 flex justify-between items-center bg-transparent border-none cursor-pointer text-left"
                >
                  <span className="font-body text-base font-semibold text-navy-900 pr-4">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 shrink-0 transition-transform duration-300 ${
                      openIndex === i ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-350 ${
                    openIndex === i ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <p className="font-body text-[0.92rem] leading-[1.7] text-gray-500 px-6 pb-5">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
