'use client';

import { Star } from 'lucide-react';
import { FadeUp } from '@/components/ui/fade-up';
import { testimonials } from '@/data/testimonials';

export function TestimonialsSection() {
  return (
    <section className="bg-white section-padding">
      <div className="container-site">
        <FadeUp>
          <div className="text-center mb-16">
            <span className="label-overline block mb-3">Reviews</span>
            <h2 className="font-display font-extrabold text-h2 text-navy-900">
              Trusted by Sydney Homeowners
            </h2>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.slice(0, 3).map((t, i) => (
            <FadeUp key={i} delay={i * 0.1}>
              <div className="bg-surface-50 rounded-[20px] p-8 border border-surface-200 h-full flex flex-col">
                <div className="flex gap-0.5 mb-5">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="font-body text-[0.95rem] leading-[1.7] text-gray-500 italic flex-1 mb-6">
                  &ldquo;{t.text}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-navy-800 flex items-center justify-center font-display font-bold text-sm text-ember-400">
                    {t.name[0]}
                  </div>
                  <div>
                    <div className="font-body font-semibold text-sm text-navy-900">
                      {t.name}
                    </div>
                    <div className="font-body text-xs text-gray-400">
                      {t.location}
                    </div>
                  </div>
                </div>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
