'use client';

import Link from 'next/link';
import { ArrowRight, Phone, Shield, ChevronDown } from 'lucide-react';
import { FadeUp } from '@/components/ui/fade-up';
import { siteConfig } from '@/data/site-config';

export function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 overflow-hidden">
      {/* Pattern overlay */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            radial-gradient(circle at 20% 50%, rgba(232,99,43,0.06) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(42,79,122,0.15) 0%, transparent 50%),
            linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 100% 100%, 60px 60px, 60px 60px',
        }}
      />

      {/* Decorative shield shapes */}
      <div className="absolute top-[15%] right-[10%] opacity-[0.04]">
        <Shield className="w-72 h-72" />
      </div>
      <div className="absolute bottom-[10%] left-[5%] opacity-[0.03] -rotate-[15deg]">
        <Shield className="w-48 h-48 text-ember-500" />
      </div>

      <div className="relative z-10 container-site py-32 md:py-40">
        <div className="max-w-[720px]">
          <FadeUp>
            <div className="inline-flex items-center gap-2 bg-ember-500/12 border border-ember-500/25 rounded-full px-4 py-1.5 mb-7">
              <div className="w-1.5 h-1.5 rounded-full bg-ember-400 animate-pulse-dot" />
              <span className="font-body text-xs font-medium text-ember-300 tracking-wide">
                Same-Day Service Available
              </span>
            </div>
          </FadeUp>

          <FadeUp delay={0.1}>
            <h1 className="font-display font-extrabold text-display text-white mb-6">
              Your Home Deserves
              <br />
              a Shield Against
              <br />
              <span className="text-ember-400">Pests</span>
            </h1>
          </FadeUp>

          <FadeUp delay={0.2}>
            <p className="font-body text-lg md:text-xl leading-relaxed text-white/70 mb-10 max-w-[540px]">
              Fast, effective pest control backed by science — not guesswork.
              Licensed technicians. Transparent pricing. Guaranteed results.
            </p>
          </FadeUp>

          <FadeUp delay={0.3}>
            <div className="flex flex-wrap gap-4 items-center">
              <Link href="/quote" className="btn-primary no-underline">
                Get a Free Quote
                <ArrowRight className="w-[18px] h-[18px]" />
              </Link>
              <a
                href={`tel:${siteConfig.phoneTel}`}
                className="btn-outline no-underline"
              >
                <Phone className="w-[18px] h-[18px] text-ember-400" />
                Call {siteConfig.phone}
              </a>
            </div>
          </FadeUp>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 animate-bobble">
        <span className="font-body text-[0.7rem] text-white tracking-[0.1em] uppercase">
          Scroll
        </span>
        <ChevronDown className="w-4 h-4 text-white" />
      </div>
    </section>
  );
}
