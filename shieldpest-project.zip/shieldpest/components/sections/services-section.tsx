'use client';

import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { FadeUp } from '@/components/ui/fade-up';
import { pestIconMap } from '@/components/ui/pest-icons';
import { services } from '@/data/services';

function ServiceCard({ service }: { service: (typeof services)[0] }) {
  const IconComponent = pestIconMap[service.icon];

  return (
    <Link
      href={`/services/${service.slug}`}
      className="card-base p-7 flex flex-col no-underline group h-full"
    >
      <div className="w-14 h-14 rounded-[14px] bg-surface-50 group-hover:bg-navy-800 flex items-center justify-center text-navy-600 group-hover:text-ember-400 mb-5 transition-all duration-300">
        {IconComponent && <IconComponent />}
      </div>
      <h3 className="font-display font-bold text-lg text-navy-900 mb-2.5 tracking-tight">
        {service.shortTitle}
      </h3>
      <p className="font-body text-sm leading-relaxed text-gray-500 flex-1">
        {service.cardDescription}
      </p>
      <div className="flex items-center gap-1.5 mt-5 font-body text-sm font-semibold text-navy-600 group-hover:text-ember-500 transition-colors">
        Learn more
        <ArrowRight className="w-4 h-4" />
      </div>
    </Link>
  );
}

export function ServicesSection() {
  return (
    <section id="services" className="bg-surface-50 section-padding">
      <div className="container-site">
        <FadeUp>
          <div className="text-center mb-16">
            <span className="label-overline block mb-3">Our Services</span>
            <h2 className="font-display font-extrabold text-h2 text-navy-900 mb-4">
              Targeted Solutions for Every Threat
            </h2>
            <p className="font-body text-base leading-relaxed text-gray-500 max-w-[520px] mx-auto">
              We don&apos;t spray and pray. Every treatment is tailored to your
              home, your pest, and your peace of mind.
            </p>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {services.map((svc, i) => (
            <FadeUp key={svc.slug} delay={i * 0.05}>
              <ServiceCard service={svc} />
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
