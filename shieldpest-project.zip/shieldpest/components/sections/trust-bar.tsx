const trustItems = [
  { label: '4.9★ from 500+ Reviews', icon: '★' },
  { label: 'Licensed & Fully Insured', icon: '🛡' },
  { label: 'Same-Day Service', icon: '⚡' },
  { label: '100% Satisfaction Guarantee', icon: '✓' },
  { label: 'Eco-Friendly Options', icon: '🌿' },
];

export function TrustBar() {
  return (
    <section className="bg-white border-b border-surface-200 py-5">
      <div className="container-site flex flex-wrap justify-center gap-x-9 gap-y-3">
        {trustItems.map((item, i) => (
          <div key={i} className="flex items-center gap-2 py-2">
            <span className="text-base">{item.icon}</span>
            <span className="font-body text-sm font-semibold text-navy-900">
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
