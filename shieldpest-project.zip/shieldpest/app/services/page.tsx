import type { Metadata } from 'next';
import { ServicesSection } from '@/components/sections/services-section';
import { CTABanner } from '@/components/sections/cta-banner';
import { BreadcrumbSchema } from '@/components/seo/json-ld';

export const metadata: Metadata = {
  title: 'Pest Control Services',
  description:
    'Professional pest control services including termite treatment, cockroach control, rodent removal, and more. Licensed technicians, guaranteed results.',
};

export default function ServicesPage() {
  return (
    <>
      <BreadcrumbSchema
        items={[
          { name: 'Home', href: '/' },
          { name: 'Services', href: '/services' },
        ]}
      />
      <div className="pt-24">
        <ServicesSection />
        <CTABanner />
      </div>
    </>
  );
}
