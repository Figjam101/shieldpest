import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          900: '#0B1426',
          800: '#111D35',
          700: '#162847',
          600: '#1E3A5F',
          500: '#2A4F7A',
        },
        ember: {
          600: '#D04E1A',
          500: '#E8632B',
          400: '#F07A42',
          300: '#F49560',
        },
        surface: {
          50: '#F8F9FB',
          100: '#F0F2F5',
          200: '#E2E5EB',
          300: '#C8CDD6',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'Plus Jakarta Sans', 'sans-serif'],
        body: ['var(--font-body)', 'DM Sans', 'sans-serif'],
      },
      fontSize: {
        'display': ['clamp(3rem, 5vw, 4.5rem)', { lineHeight: '1.08', letterSpacing: '-0.03em' }],
        'h1': ['clamp(2.25rem, 3.5vw, 3rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'h2': ['clamp(1.75rem, 2.5vw, 2.25rem)', { lineHeight: '1.15', letterSpacing: '-0.02em' }],
        'h3': ['clamp(1.25rem, 2vw, 1.5rem)', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'body-lg': ['1.125rem', { lineHeight: '1.6' }],
      },
      spacing: {
        'section': 'clamp(4rem, 8vw, 8rem)',
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.25rem',
      },
      boxShadow: {
        'card': '0 1px 4px rgba(11,20,38,0.04)',
        'card-hover': '0 8px 32px rgba(11,20,38,0.08)',
        'cta': '0 4px 24px rgba(232,99,43,0.35)',
        'cta-hover': '0 6px 32px rgba(232,99,43,0.45)',
      },
      keyframes: {
        'fade-up': {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-dot': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        bobble: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(8px)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.6s ease forwards',
        'pulse-dot': 'pulse-dot 2s ease infinite',
        'bobble': 'bobble 2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
